"""
===============================================================================
Archivo:        run_coverage_dashboard.py
Ubicación:      dash_test/run_coverage_dashboard.py
Descripción:    Ejecuta pruebas Pytest + Coverage y genera Dashboard Plotly.
Autor:          Andres Felipe Rodriguez Roa
Fecha:          2025/11/10
Radicado:       v0007af
===============================================================================
"""

import subprocess
from pathlib import Path


def run_command(cmd: str):
    print(f"\n▶ Ejecutando: {cmd}")
    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        raise RuntimeError(f"❌ Error al ejecutar: {cmd}")


def main():
    reports_path = Path("reports")
    reports_path.mkdir(exist_ok=True)

    print("🧪 Ejecutando pruebas y generando reportes de cobertura...")
    run_command("coverage run -m pytest")

    print("📊 Exportando cobertura a JSON...")
    run_command("coverage json -o reports/coverage.json")

    print("🧠 Mostrando cobertura en consola...")
    run_command("coverage report -m")

    print("🌐 Generando reporte HTML interactivo...")
    run_command("coverage html")

    print("🚀 Generando dashboard con Plotly...")
    run_command("python dash_test/coverage_dashboard.py")

    print("\n✅ Proceso completado. Abre el archivo:")
    print("   reports/coverage_dashboard.html")
    
    print("🚀 Iniciando Dashboard interactivo...")
    run_command("python dash_test/coverage_dashboard_plotly.py")


if __name__ == "__main__":
    main()
